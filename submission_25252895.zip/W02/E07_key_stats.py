"""Composition. How un-random is a sequence of keypresses? SOLUTION.

Run the tests:

    python -m doctest W02/E07_key_stats.py

No output means every test passed.

The oracle beats you because your typing has structure. These two functions
measure two kinds of structure directly, without any model at all.

QUESTION: for a genuinely random sequence, what would you expect switch_rate
to be? Write your answer in the comment at the bottom.
"""


def longest_run(history):
    """Return the length of the longest run of one repeated key.

    A run is a stretch of the same character. In "ffdff" the runs are
    "ff", "d", "ff", so the longest is 2.

    >>> longest_run("ffdff")
    2
    >>> longest_run("fffff")
    5
    >>> longest_run("fdfdfd")
    1
    >>> longest_run("f")
    1

    An empty history has no runs at all:

    >>> longest_run("")
    0
    """
    count = 0
    topScore = 0
    lastLetter = ''
    for letter in history:
        #if the letter is equal lastletter increment the count 
        #overwise start the count at 1
        if letter == lastLetter:
             count += 1
        else:
             count = 1
        #assign the lastg letter to be the new letter at thsi point in the for loop
        lastLetter = letter
        #if the count is greater than top score then assign the topscore to be the count
        if count > topScore:
             topScore = count
    return topScore


def switch_rate(history):
    """Return the fraction of keypresses that differed from the one before.

    Count the places where the key changed, and divide by the number of
    places where it could have changed, which is one less than the length.

    >>> switch_rate("fdfdfd")     # changes every time
    1.0
    >>> switch_rate("ffffff")     # never changes
    0.0
    >>> switch_rate("ffdd")       # one change out of three chances
    0.3333333333333333
    >>> round(switch_rate("fdfdff"), 2)
    0.8

    A sequence with no pairs in it has no chances to change, so there is
    nothing to average and we say 0.0 rather than dividing by zero:

    >>> switch_rate("f")
    0.0
    >>> switch_rate("")
    0.0
    """

    #handling less than 2 length values
    if len(history) < 2:
        return 0.0
    
    lastLetter = history[0]
    countOfSwitchs = 0


    for letter in history:
        #detect a change in the history of history in the for loop and increment the count of switch
        if letter != lastLetter:
            countOfSwitchs += 1
            lastLetter = letter

    #returning the count divided by the length of history -1 as it is the total possibel transition value
    return  countOfSwitchs/(len(history)-1)


# ANSWER: I would expect the switch rate to be 50% or 0.5 as the 
# chances it switchs is 50 % each time the letter changes
