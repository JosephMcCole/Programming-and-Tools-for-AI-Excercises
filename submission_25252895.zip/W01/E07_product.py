"""Drill. Python has sum() built in, but not product().

Run the tests:

    python -m doctest W01/E07_product.py

No output means every test passed.
"""


def product(L):
    """Return the product of the numbers in L.

    The sum of an empty list is 0, but the product of an empty list is 1.

    >>> product([1, 1, 1])
    1
    >>> product([1, 2, 3])
    6
    >>> product([])
    1
    >>> product([2, 3, 4])
    24
    """
    total = 1
    #setting the inital value to be 1 since it a multiplication value it cant be zero and 
    #so an empty list will return 1
    for item in L:
        total *= item # for each item in L each item is multiplied by total and then the next value
    return total


